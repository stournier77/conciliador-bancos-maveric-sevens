
import io
import os
import re
import sys
import subprocess
from datetime import datetime, date
from pathlib import Path

import pandas as pd
import numpy as np
import streamlit as st

APP_VERSION = "1.0"
APP_NAME = "Conciliador Bancos - Maveric Sevens"

st.set_page_config(
    page_title=APP_NAME,
    layout="wide",
    page_icon="💵",
)

# -----------------------------
# Utilidades
# -----------------------------

def install_if_missing(pkg_name, import_name=None):
    import_name = import_name or pkg_name
    try:
        __import__(import_name)
        return True
    except Exception:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg_name])
            return True
        except Exception:
            return False

def ensure_xls_support():
    # xlrd es necesario para .xls viejos
    try:
        import xlrd  # noqa
        return True
    except Exception:
        return install_if_missing("xlrd", "xlrd")

def to_number(x):
    if pd.isna(x):
        return 0.0
    if isinstance(x, (int, float, np.integer, np.floating)):
        return 0.0 if pd.isna(x) else float(x)
    s = str(x).strip()
    if not s or s == "-":
        return 0.0
    s = s.replace("$", "").replace("USD", "").replace("UYU", "").replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

def norm_text(x):
    if pd.isna(x):
        return ""
    return re.sub(r"\s+", " ", str(x).strip().upper().replace("ITAÚ", "ITAU"))

def parse_date_strict(x):
    if pd.isna(x):
        return pd.NaT
    if isinstance(x, (pd.Timestamp, datetime, date)):
        dt = pd.to_datetime(x, errors="coerce")
    elif isinstance(x, str):
        s = x.strip()
        if not s or not re.search(r"\d{1,4}[-/]\d{1,2}[-/]\d{1,4}", s):
            return pd.NaT
        dt = pd.to_datetime(s, errors="coerce", dayfirst=True)
    else:
        return pd.NaT
    if pd.isna(dt) or dt.year < 2020 or dt.year > 2035:
        return pd.NaT
    return dt

def is_blank_row(row):
    return all(pd.isna(v) or str(v).strip() == "" for v in row.values)

def row_contains_trash(row):
    txt = " ".join("" if pd.isna(v) else str(v) for v in row.values).upper().replace("Ó", "O")
    return (
        "TOTAL DE LA TRANSACCION" in txt
        or "TOTAL DE LA TRANSACCIÓN" in txt
        or "BALANCE DEL PERIODO" in txt
        or "BALANCE DEL PERÍODO" in txt
    )

def valid_pair(ing, egr):
    ing = to_number(ing)
    egr = to_number(egr)
    return (abs(ing) > 0 and abs(egr) == 0) or (abs(egr) > 0 and abs(ing) == 0)

def read_excel_uploaded(uploaded_file, header=None):
    name = uploaded_file.name.lower()
    data = uploaded_file.read()
    uploaded_file.seek(0)
    if name.endswith(".xls"):
        ensure_xls_support()
        return pd.read_excel(io.BytesIO(data), sheet_name=None, header=header, engine="xlrd")
    return pd.read_excel(io.BytesIO(data), sheet_name=None, header=header, engine="openpyxl")

def detect_bank_name(filename, manual_value):
    if manual_value and manual_value.strip():
        return manual_value.strip().upper().replace("ITAÚ", "ITAU")
    f = filename.upper().replace("ITAÚ", "ITAU")
    for b in ["ITAU", "BROU", "HSBC", "SANTANDER", "BBVA", "SCOTIABANK"]:
        if b in f:
            return b
    return "BANCO"

# -----------------------------
# Preparación de datos
# -----------------------------

def prepare_maveric(workbook_sheets):
    first_sheet = list(workbook_sheets.keys())[0]
    raw = workbook_sheets[first_sheet]
    raw = raw[~raw.apply(is_blank_row, axis=1)].copy()
    dates = raw.iloc[:, 0].apply(parse_date_strict)
    mask = dates.notna() & (~raw.apply(row_contains_trash, axis=1))
    df = raw.loc[mask].copy().reset_index(drop=True)
    dates = dates.loc[mask].reset_index(drop=True)

    out = pd.DataFrame(index=df.index)
    out["Maveric_RowID"] = range(1, len(df) + 1)
    out["Maveric_Fecha"] = pd.to_datetime(dates).dt.date
    out["Maveric_Movimiento"] = df.iloc[:, 1] if df.shape[1] > 1 else ""
    out["Maveric_Origen"] = df.iloc[:, 2] if df.shape[1] > 2 else ""
    out["Maveric_Destino"] = df.iloc[:, 3] if df.shape[1] > 3 else ""
    out["Maveric_Detalle"] = df.iloc[:, 4] if df.shape[1] > 4 else ""
    out["Maveric_Concepto"] = df.iloc[:, 5] if df.shape[1] > 5 else ""
    out["Maveric_Ingreso"] = df.iloc[:, 6].apply(to_number) if df.shape[1] > 6 else 0.0
    out["Maveric_Egreso"] = df.iloc[:, 7].apply(to_number) if df.shape[1] > 7 else 0.0
    out["Maveric_Texto_Busqueda"] = (
        out["Maveric_Movimiento"].astype(str) + " " +
        out["Maveric_Detalle"].astype(str) + " " +
        out["Maveric_Concepto"].astype(str)
    ).map(norm_text)
    out["Par_Ingreso_Egreso_Valido"] = out.apply(
        lambda r: valid_pair(r["Maveric_Ingreso"], r["Maveric_Egreso"]),
        axis=1
    )
    return out.reset_index(drop=True)

def prepare_bank_all(workbook_sheets):
    all_rows = []
    for sheet_name, raw in workbook_sheets.items():
        raw = raw[~raw.apply(is_blank_row, axis=1)].copy()
        if raw.empty or raw.shape[1] < 7:
            continue

        dates = raw.iloc[:, 0].apply(parse_date_strict)
        mask = dates.notna() & (~raw.apply(row_contains_trash, axis=1))
        df = raw.loc[mask].copy().reset_index(drop=True)
        dates = dates.loc[mask].reset_index(drop=True)
        if df.empty:
            continue

        out = pd.DataFrame(index=df.index)
        out["Banco_Hoja"] = sheet_name
        out["Banco_Fecha"] = pd.to_datetime(dates).dt.date
        out["Banco_Cheque_Ref"] = df.iloc[:, 1] if df.shape[1] > 1 else ""
        out["Banco_Movimiento"] = df.iloc[:, 2] if df.shape[1] > 2 else ""
        out["Banco_Detalle"] = df.iloc[:, 3] if df.shape[1] > 3 else ""
        out["Banco_Debito"] = df.iloc[:, 5].apply(to_number) if df.shape[1] > 5 else 0.0
        out["Banco_Credito"] = df.iloc[:, 6].apply(to_number) if df.shape[1] > 6 else 0.0
        out["Banco_Texto_Busqueda"] = (
            out["Banco_Cheque_Ref"].astype(str) + " " +
            out["Banco_Movimiento"].astype(str) + " " +
            out["Banco_Detalle"].astype(str)
        ).map(norm_text)
        all_rows.append(out)

    if not all_rows:
        return pd.DataFrame()
    return pd.concat(all_rows, ignore_index=True)

# -----------------------------
# Matching
# -----------------------------

def text_match(mav_text, bank_text):
    mt = norm_text(mav_text)
    bt = norm_text(bank_text)
    if not mt or not bt:
        return False
    stop = {
        "EFECTIVO", "BANCO", "ITAU", "PAGO", "TRANSFERENCIA", "GASTOS",
        "GASTO", "CH", "SA", "SAS", "SRL", "LTDA", "CLIENTES"
    }
    words = [w for w in re.split(r"[^A-Z0-9ÁÉÍÓÚÑ]+", mt) if len(w) >= 4 and w not in stop]
    return any(w in bt for w in words) or mt in bt or bt in mt

def same_date(a, b):
    da = pd.to_datetime(a, errors="coerce")
    db = pd.to_datetime(b, errors="coerce")
    return (not pd.isna(da)) and (not pd.isna(db)) and da.date() == db.date()

def movement_tokens(value):
    s = norm_text(value)
    return [w for w in re.split(r"[^A-Z0-9]+", s) if len(w) >= 4 and any(ch.isdigit() for ch in w)]

def is_tarjeta(origen, concepto):
    return ("TRJ" in norm_text(concepto)) or ("TARJETAS" in norm_text(origen))

def contains_proveedores(destino):
    return "PROVEEDORES" in norm_text(destino)

def contains_gasto_bancario(destino, detalle):
    txt = norm_text(destino) + " " + norm_text(detalle)
    return "GASTO BANCARIO" in txt or "GASTOS BANCARIOS" in txt

def contains_arqueo(row):
    txt = " ".join(norm_text(v) for v in row.values)
    return "ARQUEO" in txt

def classify_and_match(mav, bank, banco_name):
    banco_key = norm_text(banco_name)
    rows = []
    used_bank = set()

    for _, r in mav.iterrows():
        ingreso = to_number(r["Maveric_Ingreso"])
        egreso = to_number(r["Maveric_Egreso"])
        origen = norm_text(r["Maveric_Origen"])
        destino = norm_text(r["Maveric_Destino"])
        concepto = norm_text(r["Maveric_Concepto"])

        tipo = "Otros"
        amount = None
        bank_col = None
        motivo_base = ""

        if not r["Par_Ingreso_Egreso_Valido"]:
            motivo_base = "Ingreso/Egreso inválido: uno debe ser cero"
        elif banco_key in destino and ingreso > 0 and egreso == 0:
            tipo, amount, bank_col = "Ingreso", ingreso, "Banco_Credito"
        elif banco_key in origen and egreso > 0 and ingreso == 0:
            tipo, amount, bank_col = "Egreso", egreso, "Banco_Debito"
        elif banco_key in origen or banco_key in destino:
            motivo_base = "Banco aparece pero el importe está en columna contraria"
        else:
            motivo_base = "Origen/Destino no contiene banco"

        match = None
        estado = "OTROS" if tipo == "Otros" else "REVISAR"
        motivo = motivo_base
        fecha_en_bancos = ""

        if tipo in ["Ingreso", "Egreso"] and not bank.empty:
            amount_candidates = bank[bank[bank_col].round(2) == round(amount, 2)].copy()
            movs = movement_tokens(r["Maveric_Movimiento"])
            doc_candidates = []

            if movs and not amount_candidates.empty:
                for bidx, br in amount_candidates.iterrows():
                    bank_text = norm_text(br["Banco_Texto_Busqueda"])
                    if any(tok in bank_text for tok in movs):
                        doc_candidates.append((bidx, br))

            if doc_candidates:
                scored = []
                for bidx, br in doc_candidates:
                    score = 100
                    if bidx not in used_bank:
                        score += 10
                    if text_match(r["Maveric_Texto_Busqueda"], br["Banco_Texto_Busqueda"]):
                        score += 8
                    if same_date(r["Maveric_Fecha"], br["Banco_Fecha"]):
                        score += 5
                    scored.append((score, bidx, br))
                scored.sort(key=lambda x: x[0], reverse=True)
                _, best_idx, match = scored[0]
                used_bank.add(best_idx)
                estado = "OK en BANCOS"
                fecha_en_bancos = match.get("Banco_Fecha", "")
                motivo = "Importe + documento encontrado en bancos"
                if not same_date(r["Maveric_Fecha"], fecha_en_bancos):
                    motivo += " en otra fecha"
            else:
                same_day = amount_candidates[amount_candidates["Banco_Fecha"].apply(lambda x: same_date(r["Maveric_Fecha"], x))].copy()
                if same_day.empty:
                    estado = "REVISAR"
                    motivo = "No encontré importe/documento en banco"
                else:
                    scored = []
                    for bidx, br in same_day.iterrows():
                        score = 0
                        if bidx not in used_bank:
                            score += 10
                        if text_match(r["Maveric_Texto_Busqueda"], br["Banco_Texto_Busqueda"]):
                            score += 8
                        scored.append((score, bidx, br))
                    scored.sort(key=lambda x: x[0], reverse=True)
                    best_score, best_idx, match = scored[0]
                    used_bank.add(best_idx)
                    fecha_en_bancos = match.get("Banco_Fecha", "")
                    if best_score >= 18:
                        estado = "OK en BANCOS"
                        motivo = "Importe + misma fecha + texto"
                    else:
                        estado = "REVISAR"
                        motivo = "Importe + misma fecha, revisar texto"

        out = r.to_dict()
        out["Tipo"] = tipo
        out["Es_Tarjeta"] = "SI" if is_tarjeta(origen, concepto) else "NO"
        out["Es_Pago_Proveedor"] = "SI" if contains_proveedores(destino) else "NO"
        out["Es_Gasto_Bancario"] = "SI" if contains_gasto_bancario(destino, r["Maveric_Detalle"]) else "NO"
        out["Es_Arqueo"] = "SI" if contains_arqueo(r) else "NO"
        out["Estado"] = estado
        out["Fecha en Bancos"] = fecha_en_bancos
        out["Motivo"] = motivo

        if match is not None:
            out.update({
                "Banco_Hoja": match.get("Banco_Hoja", ""),
                "Banco_Fecha": match.get("Banco_Fecha", ""),
                "Banco_Cheque_Ref": match.get("Banco_Cheque_Ref", ""),
                "Banco_Movimiento": match.get("Banco_Movimiento", ""),
                "Banco_Detalle": match.get("Banco_Detalle", ""),
                "Banco_Debito": match.get("Banco_Debito", 0.0),
                "Banco_Credito": match.get("Banco_Credito", 0.0),
            })
        else:
            out.update({
                "Banco_Hoja": "",
                "Banco_Fecha": "",
                "Banco_Cheque_Ref": "",
                "Banco_Movimiento": "",
                "Banco_Detalle": "",
                "Banco_Debito": 0.0,
                "Banco_Credito": 0.0,
            })
        rows.append(out)

    return pd.DataFrame(rows)

# -----------------------------
# Excel
# -----------------------------

def add_total_row(df):
    df = df.copy()
    if df.empty:
        return df
    total = {c: "" for c in df.columns}
    total[df.columns[0]] = "TOTAL"
    for c in ["Maveric_Ingreso", "Maveric_Egreso", "Banco_Debito", "Banco_Credito"]:
        if c in df.columns:
            total[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
    return pd.concat([df, pd.DataFrame([total])], ignore_index=True)

def safe_sheet(df, cols):
    existing = [c for c in cols if c in df.columns]
    return df[existing].copy()

def build_excel(full, bank_all, bank_rango, banco_nombre, mav_filename):
    cols = [
        "Maveric_RowID", "Maveric_Fecha", "Maveric_Movimiento", "Maveric_Origen", "Maveric_Destino",
        "Maveric_Detalle", "Maveric_Concepto", "Maveric_Ingreso", "Maveric_Egreso",
        "Tipo", "Es_Tarjeta", "Es_Pago_Proveedor", "Es_Gasto_Bancario", "Es_Arqueo",
        "Estado", "Fecha en Bancos", "Motivo",
        "Banco_Hoja", "Banco_Fecha", "Banco_Cheque_Ref", "Banco_Movimiento", "Banco_Detalle",
        "Banco_Debito", "Banco_Credito", "Par_Ingreso_Egreso_Valido"
    ]
    full = safe_sheet(full, cols)

    ingresos = full[(full["Tipo"]=="Ingreso") & (full["Maveric_Ingreso"].abs()>0) & (full["Maveric_Egreso"].abs()==0)].copy()
    egresos = full[(full["Tipo"]=="Egreso") & (full["Maveric_Egreso"].abs()>0) & (full["Maveric_Ingreso"].abs()==0)].copy()
    tarjetas = full[full["Es_Tarjeta"]=="SI"].copy()
    revisar = full[full["Estado"]=="REVISAR"].copy()
    pago_proveedores = full[full["Es_Pago_Proveedor"]=="SI"].copy()
    gasto_bancario = full[full["Es_Gasto_Bancario"]=="SI"].copy()
    arqueo = full[full["Es_Arqueo"]=="SI"].copy()

    # Otros = no cae en ninguna categoría específica y no es ingreso/egreso clasificado.
    otros = full[
        (full["Tipo"]=="Otros")
        & (full["Es_Tarjeta"]!="SI")
        & (full["Es_Pago_Proveedor"]!="SI")
        & (full["Es_Gasto_Bancario"]!="SI")
        & (full["Es_Arqueo"]!="SI")
    ].copy()

    banco_usado = full[full["Banco_Fecha"].astype(str).str.strip() != ""][
        ["Banco_Hoja", "Banco_Fecha", "Banco_Cheque_Ref", "Banco_Movimiento", "Banco_Detalle", "Banco_Debito", "Banco_Credito"]
    ].drop_duplicates().copy()

    mav_dates = pd.to_datetime(full["Maveric_Fecha"], errors="coerce")
    min_date = mav_dates.min().date() if not mav_dates.isna().all() else ""
    max_date = mav_dates.max().date() if not mav_dates.isna().all() else ""

    resumen = pd.DataFrame([
        ["Banco detectado", banco_nombre],
        ["Versión lógica", APP_VERSION],
        ["Fecha creación", datetime.now().strftime("%d/%m/%Y %H:%M")],
        ["Archivo Maveric usado", mav_filename],
        ["Rango Maveric leído", f"{min_date} a {max_date}"],
        ["Filas Maveric limpias", len(full)],
        ["Banco total usado para búsqueda", len(bank_all)],
        ["Banco dentro del rango Maveric", len(bank_rango)],
        ["OK en BANCOS", int((full["Estado"]=="OK en BANCOS").sum())],
        ["REVISAR", int((full["Estado"]=="REVISAR").sum())],
        ["OTROS", int((full["Estado"]=="OTROS").sum())],
        ["Ingresos", len(ingresos)],
        ["Egresos", len(egresos)],
        ["Tarjetas", len(tarjetas)],
        ["Pago a Proveedores", len(pago_proveedores)],
        ["Gasto Bancario", len(gasto_bancario)],
        ["Arqueo", len(arqueo)],
        ["Otros datos", len(otros)],
        ["Total ingresos Maveric", ingresos["Maveric_Ingreso"].sum()],
        ["Total créditos Banco vinculados a ingresos", ingresos["Banco_Credito"].sum()],
        ["Diferencia ingresos", ingresos["Maveric_Ingreso"].sum() - ingresos["Banco_Credito"].sum()],
        ["Total egresos Maveric", egresos["Maveric_Egreso"].sum()],
        ["Total débitos Banco vinculados a egresos", egresos["Banco_Debito"].sum()],
        ["Diferencia egresos", egresos["Maveric_Egreso"].sum() - egresos["Banco_Debito"].sum()],
    ], columns=["Concepto", "Valor"])

    notas = pd.DataFrame([
        ["Base", "La salida se arma únicamente con filas del archivo Maveric. El banco no agrega movimientos propios."],
        ["Búsqueda en bancos", "Busca documento/movimiento de Maveric en todo el archivo de bancos, aunque sea otra fecha."],
        ["Fecha en Bancos", "Muestra la fecha real encontrada en el banco."],
        ["Estado", "OK se muestra como OK en BANCOS. Diferencias quedan REVISAR."],
        ["Tarjetas", "Va a Tarjetas si Maveric F contiene TRJ o Maveric C/Origen contiene TARJETAS."],
        ["Pago a Proveedores", "Va a Pago a Proveedores si Maveric Destino contiene PROVEEDORES."],
        ["Gasto Bancario", "Va a Gasto Bancario si Maveric Destino o Cliente/Proveedor contiene GASTO BANCARIO/GASTOS BANCARIOS."],
        ["Arqueo", "Todo lo que contiene ARQUEO va a la hoja Arqueo y se excluye de Otros_datos."],
        ["Formato", "Se dejan columnas fijas y legibles, sin ajuste de texto masivo ni bandas celestes/blancas. OK verde, Revisar rojo."],
    ], columns=["Regla", "Detalle"])

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter", datetime_format="dd/mm/yyyy", date_format="dd/mm/yyyy") as writer:
        resumen.to_excel(writer, sheet_name="Resumen", index=False)
        add_total_row(full).to_excel(writer, sheet_name="Espejo_Maveric", index=False)
        add_total_row(ingresos).to_excel(writer, sheet_name="Ingresos", index=False)
        add_total_row(egresos).to_excel(writer, sheet_name="Egresos", index=False)
        add_total_row(tarjetas).to_excel(writer, sheet_name="Tarjetas", index=False)
        add_total_row(otros).to_excel(writer, sheet_name="Otros_datos", index=False)
        add_total_row(revisar).to_excel(writer, sheet_name="Revisar diferencias", index=False)
        add_total_row(pago_proveedores).to_excel(writer, sheet_name="Pago a Proveedores", index=False)
        add_total_row(gasto_bancario).to_excel(writer, sheet_name="Gasto Bancario", index=False)
        add_total_row(arqueo).to_excel(writer, sheet_name="Arqueo", index=False)
        add_total_row(banco_usado).to_excel(writer, sheet_name="Banco_Usado", index=False)
        add_total_row(bank_rango).to_excel(writer, sheet_name="Banco_Rango_Maveric", index=False)
        notas.to_excel(writer, sheet_name="Notas_Reglas", index=False)

        wb = writer.book
        header_fmt = wb.add_format({
            "bold": True, "bg_color": "#D9EAF7", "border": 1,
            "text_wrap": False, "valign": "vcenter"
        })
        money_fmt = wb.add_format({"num_format": "#,##0.00", "text_wrap": False})
        date_fmt = wb.add_format({"num_format": "dd/mm/yyyy", "text_wrap": False})
        total_fmt = wb.add_format({"bold": True, "top": 2, "bg_color": "#F3F4F6", "text_wrap": False})
        ok_fmt = wb.add_format({"bg_color": "#C6EFCE", "font_color": "#006100", "text_wrap": False})
        rev_fmt = wb.add_format({"bg_color": "#FFC7CE", "font_color": "#9C0006", "text_wrap": False})
        otros_fmt = wb.add_format({"bg_color": "#E7E6E6", "text_wrap": False})
        body_fmt = wb.add_format({"text_wrap": False, "valign": "vcenter"})

        sheet_dfs = {
            "Espejo_Maveric": full, "Ingresos": ingresos, "Egresos": egresos, "Tarjetas": tarjetas,
            "Otros_datos": otros, "Revisar diferencias": revisar, "Pago a Proveedores": pago_proveedores,
            "Gasto Bancario": gasto_bancario, "Arqueo": arqueo, "Banco_Usado": banco_usado,
            "Banco_Rango_Maveric": bank_rango
        }

        for sheet_name, ws in writer.sheets.items():
            max_row = ws.dim_rowmax
            max_col = ws.dim_colmax
            ws.freeze_panes(1, 0)
            ws.set_row(0, 22, header_fmt)
            if max_row is not None and max_col is not None:
                ws.autofilter(0, 0, max_row, max_col)
                # filas normales, nada de 40 px ni wrap molesto
                for r in range(1, max_row + 1):
                    ws.set_row(r, 18, body_fmt)
                ws.set_row(max_row, 18, total_fmt)

            # Anchos fijos legibles, sin tener que "Autoajustar"
            ws.set_column(0, 0, 12, body_fmt)
            ws.set_column(1, 1, 12, date_fmt)
            ws.set_column(2, 2, 16, body_fmt)
            ws.set_column(3, 4, 22, body_fmt)
            ws.set_column(5, 6, 30, body_fmt)
            ws.set_column(7, 8, 14, money_fmt)
            ws.set_column(9, 13, 16, body_fmt)
            ws.set_column(14, 14, 16, body_fmt)  # Estado
            ws.set_column(15, 15, 15, date_fmt)  # Fecha en Bancos
            ws.set_column(16, 16, 42, body_fmt)  # Motivo
            ws.set_column(17, 21, 22, body_fmt)
            ws.set_column(22, 23, 14, money_fmt)
            ws.set_column(24, 24, 16, body_fmt)

            if sheet_name == "Resumen":
                ws.set_column(0, 0, 42, body_fmt)
                ws.set_column(1, 1, 85, body_fmt)
                for r in range(1, max_row + 1):
                    ws.set_row(r, 18, body_fmt)

            if sheet_name == "Notas_Reglas":
                ws.set_column(0, 0, 24, body_fmt)
                ws.set_column(1, 1, 105, body_fmt)
                for r in range(1, max_row + 1):
                    ws.set_row(r, 22, body_fmt)

            df_ref = sheet_dfs.get(sheet_name)
            if df_ref is not None and "Estado" in df_ref.columns and max_row and max_col:
                estado_col = list(df_ref.columns).index("Estado")
                # Estado está dentro de A:Z en nuestro layout
                col_letter = chr(65 + estado_col)
                ws.conditional_format(1, 0, max_row, max_col, {
                    "type": "formula", "criteria": f'=${col_letter}2="OK en BANCOS"', "format": ok_fmt
                })
                ws.conditional_format(1, 0, max_row, max_col, {
                    "type": "formula", "criteria": f'=${col_letter}2="REVISAR"', "format": rev_fmt
                })
                ws.conditional_format(1, 0, max_row, max_col, {
                    "type": "formula", "criteria": f'=${col_letter}2="OTROS"', "format": otros_fmt
                })

    output.seek(0)
    stats = {
        "filas": len(full),
        "ok": int((full["Estado"]=="OK en BANCOS").sum()),
        "revisar": int((full["Estado"]=="REVISAR").sum()),
        "otros": int((full["Estado"]=="OTROS").sum()),
        "tarjetas": len(tarjetas),
        "proveedores": len(pago_proveedores),
        "gasto_bancario": len(gasto_bancario),
        "arqueo": len(arqueo),
        "rango": f"{min_date} a {max_date}",
    }
    return output, stats

def run_conciliation(banco_file, maveric_file, banco_nombre):
    banco_sheets = read_excel_uploaded(banco_file, header=None)
    mav_sheets = read_excel_uploaded(maveric_file, header=None)

    banco_nombre = detect_bank_name(banco_file.name, banco_nombre)
    mav = prepare_maveric(mav_sheets)
    bank_all = prepare_bank_all(banco_sheets)

    if mav.empty:
        raise ValueError("No encontré movimientos válidos en Maveric. Revisá que la columna A tenga fechas reales.")

    mav_dates = pd.to_datetime(mav["Maveric_Fecha"], errors="coerce")
    min_date = mav_dates.min().date()
    max_date = mav_dates.max().date()

    if bank_all.empty:
        bank_rango = pd.DataFrame()
    else:
        bank_rango = bank_all[(bank_all["Banco_Fecha"] >= min_date) & (bank_all["Banco_Fecha"] <= max_date)].copy()

    full = classify_and_match(mav, bank_all, banco_nombre)
    excel, stats = build_excel(full, bank_all, bank_rango, banco_nombre, maveric_file.name)

    return excel, stats, banco_nombre

# -----------------------------
# UI
# -----------------------------

st.title("💵 Conciliador Bancos - Maveric Sevens")
st.caption(f"Versión {APP_VERSION}")

with st.sidebar:
    st.image(str(Path(__file__).parent / "assets" / "icon_sevens_bancos.png"), width=120)
    st.markdown("### Carga")
    banco_file = st.file_uploader("Subir Excel del banco", type=["xlsx", "xls"])
    maveric_file = st.file_uploader("Subir Excel Bancos Maveric", type=["xlsx", "xls"])
    banco_manual = st.text_input("Banco a buscar", value="", placeholder="ITAU, BROU, HSBC...")
    st.caption("Si lo dejás vacío, intento tomarlo del nombre del archivo.")
    st.markdown("---")
    st.caption("Sevens Travel · Conciliador Bancos")

st.markdown("""
La conciliación nace desde **Maveric**. El banco se usa solo para buscar el espejo:
documento/movimiento + importe, aunque esté en otra fecha bancaria.
""")

if banco_file and maveric_file:
    if st.button("Generar conciliación", type="primary"):
        try:
            with st.spinner("Conciliando..."):
                excel, stats, banco_nombre = run_conciliation(banco_file, maveric_file, banco_manual)

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Movimientos", stats["filas"])
            c2.metric("OK en BANCOS", stats["ok"])
            c3.metric("Revisar", stats["revisar"])
            c4.metric("Otros", stats["otros"])

            c5, c6, c7, c8 = st.columns(4)
            c5.metric("Tarjetas", stats["tarjetas"])
            c6.metric("Proveedores", stats["proveedores"])
            c7.metric("Gasto Bancario", stats["gasto_bancario"])
            c8.metric("Arqueo", stats["arqueo"])

            now = datetime.now().strftime("%H%M")  # hora local de la máquina donde corre la app
            rango_txt = stats["rango"].replace("2026-", "").replace(" a ", "_a_").replace("-", "")
            file_name = f"Conciliacion_Bancos_Maveric_{banco_nombre}_{rango_txt}_v{APP_VERSION.replace('.', '_')}_{now}.xlsx"

            st.success("Conciliación generada.")
            st.download_button(
                "Descargar Excel conciliado",
                data=excel,
                file_name=file_name,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        except Exception as e:
            st.error(f"No pude generar la conciliación: {e}")
else:
    st.info("Subí el Excel del banco y el Excel de Bancos Maveric para empezar.")
