import io, os, re, sys, json, uuid, platform, subprocess
from datetime import datetime, date
from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st

APP_VERSION = "1.7"
APP_NAME = "Conciliador Bancos - Maveric Sevens"
st.set_page_config(page_title=APP_NAME, layout="wide", page_icon="💵")
APP_DIR=Path(__file__).resolve().parent; ROOT_DIR=APP_DIR.parent; AUTH_FILE=ROOT_DIR/'authorized_machines.json'; ICON_PATH=APP_DIR/'assets'/'icon_sevens_bancos.png'
MONEDA_CFG={"Dólares":{"tokens":["USD","DOLARES","DÓLARES","DOLAR","DÓLAR"],"slug":"dolares"},"Pesos":{"tokens":["PESOS","UYU","URUGUAYOS"],"slug":"pesos"},"Euros":{"tokens":["EUROS","EUR"],"slug":"euros"}}
TOL=0.10

def docs_dir():
    p=Path.home()/"Documents"
    if not p.exists(): p=Path.home()/"Documentos"
    p.mkdir(exist_ok=True); return p

def out_base():
    p=docs_dir()/"archivos conciliados bancos maveric"; p.mkdir(parents=True, exist_ok=True); return p

def open_folder(path):
    try:
        path.mkdir(parents=True, exist_ok=True); s=platform.system().lower()
        if 'darwin' in s: subprocess.Popen(['open',str(path)])
        elif 'windows' in s: os.startfile(str(path))
        else: subprocess.Popen(['xdg-open',str(path)])
        return True
    except Exception: return False

def run_cmd(cmd):
    try: return subprocess.check_output(cmd,shell=True,stderr=subprocess.DEVNULL,text=True).strip()
    except Exception: return ""

def machine_id():
    s=platform.system().lower(); raw=""
    if 'darwin' in s: raw=run_cmd("ioreg -rd1 -c IOPlatformExpertDevice | awk -F'\\\"' '/IOPlatformUUID/{print $(NF-1)}'")
    elif 'windows' in s:
        raw=run_cmd('powershell -NoProfile -Command "(Get-CimInstance Win32_ComputerSystemProduct).UUID"') or run_cmd('wmic csproduct get uuid').replace('UUID','').strip()
    else: raw=run_cmd('cat /etc/machine-id')
    return (raw or str(uuid.getnode())).strip().upper()

def auth_cfg():
    default={"admin_ids":["00000000-0000-0000-0000-309C230BAEF1","86FE5326-6706-53D3-97C4-442452FDC186"],"allowed_ids":["00000000-0000-0000-0000-309C230BAEF1","86FE5326-6706-53D3-97C4-442452FDC186"],"labels":{"00000000-0000-0000-0000-309C230BAEF1":"TUKI PC","86FE5326-6706-53D3-97C4-442452FDC186":"Tuki Mac Admin"},"allow_unregistered":True}
    if not AUTH_FILE.exists(): AUTH_FILE.write_text(json.dumps(default,indent=2),encoding='utf-8')
    try: cfg=json.loads(AUTH_FILE.read_text(encoding='utf-8'))
    except Exception: cfg=default
    cfg.setdefault('labels',{}); cfg.setdefault('allow_unregistered',True); return cfg

def authorized():
    cfg=auth_cfg(); mid=machine_id(); return (mid in cfg.get('allowed_ids',[]) or cfg.get('allow_unregistered',True)), mid, cfg

def ensure_xlrd():
    try: import xlrd; return True
    except Exception:
        try: subprocess.check_call([sys.executable,'-m','pip','install','xlrd']); return True
        except Exception: return False

def norm(x):
    if pd.isna(x): return ""
    s=str(x).strip().upper();
    for a,b in {"ITAÚ":"ITAU","Ó":"O","Á":"A","É":"E","Í":"I","Ú":"U","Ñ":"N"}.items(): s=s.replace(a,b)
    return re.sub(r'\s+',' ',s)

def num(x):
    if pd.isna(x): return 0.0
    if isinstance(x,(int,float,np.integer,np.floating)): return 0.0 if pd.isna(x) else float(x)
    s=str(x).strip().replace('$','').replace('USD','').replace('UYU','').replace('EUR','').replace(' ','')
    if not s or s=='-': return 0.0
    if ',' in s and '.' in s: s=s.replace('.','').replace(',','.')
    elif ',' in s: s=s.replace(',','.')
    try: return float(s)
    except Exception: return 0.0

def amount_close(a,b): return abs(float(a or 0)-float(b or 0)) <= TOL

def parse_date(x):
    if pd.isna(x): return pd.NaT
    if isinstance(x,(pd.Timestamp,datetime,date)): dt=pd.to_datetime(x,errors='coerce')
    elif isinstance(x,str):
        s=x.strip()
        if not s or not re.search(r'\d{1,4}[-/]\d{1,2}[-/]\d{1,4}',s): return pd.NaT
        dt=pd.to_datetime(s,errors='coerce',dayfirst=True)
    else: return pd.NaT
    if pd.isna(dt) or dt.year<2020 or dt.year>2035: return pd.NaT
    return dt

def blank(row): return all(pd.isna(v) or str(v).strip()=='' for v in row.values)
def trash(row):
    t=norm(' '.join('' if pd.isna(v) else str(v) for v in row.values)); return 'TOTAL DE LA TRANSACCION' in t or 'BALANCE DEL PERIODO' in t

def read_excel(up, header=None):
    data=up.read(); up.seek(0); name=up.name.lower()
    if name.endswith('.xls'):
        ensure_xlrd(); return pd.read_excel(io.BytesIO(data),sheet_name=None,header=header,engine='xlrd')
    return pd.read_excel(io.BytesIO(data),sheet_name=None,header=header,engine='openpyxl')

def detect_bank(filename, manual):
    if manual and manual.strip(): return norm(manual)
    f=norm(filename)
    for b in ['ITAU','BROU','SANTANDER','HSBC','BBVA','SCOTIABANK']:
        if b in f: return b
    return 'BANCO'

def filter_currency(sheets, moneda):
    toks=MONEDA_CFG[moneda]['tokens']; sel={k:v for k,v in sheets.items() if any(t in norm(k) for t in toks)}
    return sel or sheets

def valid_pair(i,e):
    i=num(i); e=num(e); return (abs(i)>0 and abs(e)==0) or (abs(e)>0 and abs(i)==0)

def prepare_mav(sheets):
    raw=sheets[list(sheets.keys())[0]]; raw=raw[~raw.apply(blank,axis=1)].copy(); dates=raw.iloc[:,0].apply(parse_date); mask=dates.notna() & (~raw.apply(trash,axis=1))
    df=raw.loc[mask].copy().reset_index(drop=True); dates=dates.loc[mask].reset_index(drop=True); out=pd.DataFrame(index=df.index)
    out['Maveric_Fecha']=pd.to_datetime(dates).dt.date
    out['Maveric Ref.']=df.iloc[:,1] if df.shape[1]>1 else ''
    out['Maveric_Origen']=df.iloc[:,2] if df.shape[1]>2 else ''
    out['Maveric_Destino']=df.iloc[:,3] if df.shape[1]>3 else ''
    out['Maveric Cliente/Proveedor']=df.iloc[:,4] if df.shape[1]>4 else ''
    out['Maveric Detalle']=df.iloc[:,5] if df.shape[1]>5 else ''
    out['Maveric_Ingreso']=df.iloc[:,6].apply(num) if df.shape[1]>6 else 0.0
    out['Maveric_Egreso']=df.iloc[:,7].apply(num) if df.shape[1]>7 else 0.0
    out['Maveric_Texto_Busqueda']=(out['Maveric Ref.'].astype(str)+' '+out['Maveric Cliente/Proveedor'].astype(str)+' '+out['Maveric Detalle'].astype(str)).map(norm)
    out['Par_Ingreso_Egreso_Valido']=out.apply(lambda r: valid_pair(r['Maveric_Ingreso'],r['Maveric_Egreso']),axis=1)
    return out.reset_index(drop=True)

def prepare_bank(sheets):
    arr=[]
    for sh, raw in sheets.items():
        raw=raw[~raw.apply(blank,axis=1)].copy()
        if raw.empty or raw.shape[1]<7: continue
        dates=raw.iloc[:,0].apply(parse_date); mask=dates.notna() & (~raw.apply(trash,axis=1)); df=raw.loc[mask].copy().reset_index(drop=True); dates=dates.loc[mask].reset_index(drop=True)
        if df.empty: continue
        out=pd.DataFrame(index=df.index); out['Banco_Hoja']=sh; out['Banco_Fecha']=pd.to_datetime(dates).dt.date
        out['Banco_Cheque_Ref']=df.iloc[:,1] if df.shape[1]>1 else ''; out['Banco_Movimiento']=df.iloc[:,2] if df.shape[1]>2 else ''; out['Banco_Detalle']=df.iloc[:,3] if df.shape[1]>3 else ''
        out['Banco_Debito']=df.iloc[:,5].apply(num) if df.shape[1]>5 else 0.0; out['Banco_Credito']=df.iloc[:,6].apply(num) if df.shape[1]>6 else 0.0
        out['Banco_Texto_Busqueda']=(out['Banco_Cheque_Ref'].astype(str)+' '+out['Banco_Movimiento'].astype(str)+' '+out['Banco_Detalle'].astype(str)).map(norm)
        arr.append(out)
    return pd.concat(arr,ignore_index=True) if arr else pd.DataFrame()

def words(s): return [w for w in re.split(r'[^A-Z0-9]+',norm(s)) if w]
def text_match(mt,bt):
    mt=norm(mt); bt=norm(bt)
    if 'SEVENS TRAVEL' in mt and 'IATA' in bt: return True
    stop={'EFECTIVO','BANCO','ITAU','PAGO','TRANSFERENCIA','GASTOS','GASTO','CH','SA','SAS','SRL','LTDA','CLIENTES','PROVEEDORES'}
    ww=[w for w in re.split(r'[^A-Z0-9]+',mt) if len(w)>=4 and w not in stop]
    return any(w in bt for w in ww) or mt in bt or bt in mt

def same_date(a,b):
    da=pd.to_datetime(a,errors='coerce'); db=pd.to_datetime(b,errors='coerce'); return not pd.isna(da) and not pd.isna(db) and da.date()==db.date()
def mov_tokens(x): return [w for w in words(x) if len(w)>=4 and any(ch.isdigit() for ch in w)]
def is_tarjeta_mav(r):
    tc_words=words(r.get('Maveric Cliente/Proveedor',''))
    return ('TRJ' in norm(r.get('Maveric Detalle','')) or 'TARJETAS' in norm(r.get('Maveric_Origen','')) or 'TC' in tc_words)
def is_bank_tarj(r):
    t=norm(r.get('Banco_Texto_Busqueda','')); return 'TRJ' in t or 'TARJETA' in t or 'TARJETAS' in t or ' TC ' in f' {t} '
def is_bank_prov(r):
    t=norm(r.get('Banco_Texto_Busqueda','')); return 'PROVEEDOR' in t or 'PROVEEDORES' in t or 'PAGO' in t
def is_gasto(r):
    t=norm(r.get('Maveric_Destino',''))+' '+norm(r.get('Maveric Cliente/Proveedor','')); return 'GASTO BANCARIO' in t or 'GASTOS BANCARIOS' in t

def classify(mav, bank, banco):
    bk=norm(banco); rows=[]; used=set()
    for _,r in mav.iterrows():
        ing=num(r['Maveric_Ingreso']); egr=num(r['Maveric_Egreso']); ori=norm(r['Maveric_Origen']); des=norm(r['Maveric_Destino'])
        tipo='Otros'; amount=None; bcol=None; motivo=''
        if not r['Par_Ingreso_Egreso_Valido']: motivo='Ingreso/Egreso inválido: uno debe ser cero'
        elif bk in des and ing>0 and egr==0: tipo,amount,bcol='Ingreso',ing,'Banco_Credito'
        elif bk in ori and egr>0 and ing==0: tipo,amount,bcol='Egreso',egr,'Banco_Debito'
        elif bk in ori or bk in des: motivo='Banco aparece pero el importe está en columna contraria'
        else: motivo='Origen/Destino no contiene banco'
        match=None; estado='OTROS' if tipo=='Otros' else 'REVISAR'; fecha=''
        if tipo in ['Ingreso','Egreso'] and not bank.empty:
            cand=bank[bank[bcol].apply(lambda x: amount_close(x,amount))].copy(); toks=mov_tokens(r['Maveric Ref.']); docs=[]
            for bi,br in cand.iterrows():
                bt=norm(br['Banco_Texto_Busqueda'])
                if toks and any(t in bt for t in toks): docs.append((bi,br))
            if docs:
                scored=[]
                for bi,br in docs:
                    score=100+(10 if bi not in used else 0)+(5 if same_date(r['Maveric_Fecha'],br['Banco_Fecha']) else 0)+(3 if text_match(r['Maveric_Texto_Busqueda'],br['Banco_Texto_Busqueda']) else 0)
                    scored.append((score,bi,br))
                scored.sort(key=lambda x:x[0], reverse=True); _,bi,match=scored[0]; used.add(bi); estado='OK en BANCOS'; fecha=match.get('Banco_Fecha',''); motivo='Importe + referencia/documento' + ('' if same_date(r['Maveric_Fecha'],fecha) else ' en otra fecha')
            else:
                sd=cand[cand['Banco_Fecha'].apply(lambda x: same_date(r['Maveric_Fecha'],x))].copy()
                if sd.empty: motivo='No encontré importe/referencia en banco'
                else:
                    scored=[]
                    for bi,br in sd.iterrows(): scored.append(((10 if bi not in used else 0)+(8 if text_match(r['Maveric_Texto_Busqueda'],br['Banco_Texto_Busqueda']) else 0),bi,br))
                    scored.sort(key=lambda x:x[0], reverse=True); score,bi,match=scored[0]; used.add(bi); fecha=match.get('Banco_Fecha','')
                    estado='OK en BANCOS'; motivo='Importe + misma fecha + texto' if score>=18 else 'Importe + misma fecha dentro de tolerancia, texto distinto'
        out=r.to_dict(); out['Es_Tarjeta']='SI' if is_tarjeta_mav(out) else 'NO'; out['Es_Pago_Proveedor']='SI' if ('PROVEEDORES' in norm(out.get('Maveric_Destino','')) and out['Es_Tarjeta']!='SI') else 'NO'; out['Es_Gasto_Bancario']='SI' if is_gasto(out) else 'NO'
        out['Tipo']=tipo; out['Estado']=estado; out['Fecha en Bancos']=fecha; out['Motivo']=motivo
        if match is not None: out.update({'Banco_Hoja':match.get('Banco_Hoja',''),'Banco_Fecha':match.get('Banco_Fecha',''),'Banco_Cheque_Ref':match.get('Banco_Cheque_Ref',''),'Banco_Movimiento':match.get('Banco_Movimiento',''),'Banco_Detalle':match.get('Banco_Detalle',''),'Banco_Debito':match.get('Banco_Debito',0.0),'Banco_Credito':match.get('Banco_Credito',0.0)})
        else: out.update({'Banco_Hoja':'','Banco_Fecha':'','Banco_Cheque_Ref':'','Banco_Movimiento':'','Banco_Detalle':'','Banco_Debito':0.0,'Banco_Credito':0.0})
        rows.append(out)
    return pd.DataFrame(rows), used

def order_cols(df):
    cols=['Maveric_Fecha','Maveric Ref.','Maveric_Origen','Maveric_Destino','Maveric Cliente/Proveedor','Maveric Detalle','Maveric_Ingreso','Banco_Credito','Maveric_Egreso','Banco_Debito','Estado','Fecha en Bancos','Motivo','Tipo','Es_Tarjeta','Es_Pago_Proveedor','Es_Gasto_Bancario','Banco_Hoja','Banco_Fecha','Banco_Cheque_Ref','Banco_Movimiento','Banco_Detalle','Par_Ingreso_Egreso_Valido']
    return df[[c for c in cols if c in df.columns]].copy()
def total(df):
    df=df.copy()
    if df.empty: return df
    row={c:'' for c in df.columns}; row[df.columns[0]]='TOTAL'
    for c in ['Maveric_Ingreso','Maveric_Egreso','Banco_Debito','Banco_Credito']:
        if c in df.columns: row[c]=pd.to_numeric(df[c],errors='coerce').fillna(0).sum()
    return pd.concat([df,pd.DataFrame([row])],ignore_index=True)
def periodo_lindo(stats):
    meses={1:'ene',2:'feb',3:'mar',4:'abr',5:'may',6:'jun',7:'jul',8:'ago',9:'sep',10:'oct',11:'nov',12:'dic'}; raw=str(stats.get('periodo') or stats.get('rango') or ''); nums=re.findall(r'(20\d{2})[-]?(\d{2})[-]?(\d{2})',raw)
    if len(nums)>=2:
        y1,m1,d1=map(int,nums[0]); y2,m2,d2=map(int,nums[1]); return f'{d1}-{d2}_{meses.get(m1,m1)}_{y1}' if y1==y2 and m1==m2 else f'{d1}_{meses.get(m1,m1)}_{y1}_a_{d2}_{meses.get(m2,m2)}_{y2}'
    return raw.replace(' ','_').replace(':','').replace('/','-')
def bank_side(bank, cat):
    if bank.empty: return pd.DataFrame()
    out=[]
    for _,r in bank.iterrows():
        if cat=='tarjetas' and is_bank_tarj(r): rr=r.to_dict(); rr['Origen']='Banco'; rr['Estado']='Banco - revisar si corresponde'; out.append(rr)
        if cat=='proveedores' and is_bank_prov(r): rr=r.to_dict(); rr['Origen']='Banco'; rr['Estado']='Banco - revisar si corresponde'; out.append(rr)
    return pd.DataFrame(out)

def build_excel(full, bank, bank_rango, used, banco, moneda):
    full=order_cols(full); ing=full[(full['Tipo']=='Ingreso') & (full['Maveric_Ingreso'].abs()>0)].copy(); egr=full[(full['Tipo']=='Egreso') & (full['Maveric_Egreso'].abs()>0)].copy(); rev=full[full['Estado']=='REVISAR'].copy()
    tarj=pd.concat([full[full['Es_Tarjeta']=='SI'].copy(), bank_side(bank_rango,'tarjetas')],ignore_index=True,sort=False); prov=pd.concat([full[(full['Es_Pago_Proveedor']=='SI') & (full['Es_Tarjeta']!='SI')].copy(), bank_side(bank_rango,'proveedores')],ignore_index=True,sort=False)
    gasto=full[full['Es_Gasto_Bancario']=='SI'].copy(); otros=full[(full['Tipo']=='Otros')&(full['Es_Tarjeta']!='SI')&(full['Es_Pago_Proveedor']!='SI')&(full['Es_Gasto_Bancario']!='SI')].copy()
    mav_falta=rev[rev['Tipo'].isin(['Ingreso','Egreso'])].copy(); banco_falta=bank_rango.loc[[i for i in bank_rango.index if i not in used]].copy() if not bank_rango.empty else pd.DataFrame()
    if not banco_falta.empty: banco_falta=banco_falta[(banco_falta['Banco_Debito'].abs()>0)|(banco_falta['Banco_Credito'].abs()>0)].copy(); banco_falta['Estado']='Falta en Maveric'
    usado=full[full['Banco_Fecha'].astype(str).str.strip()!=''][[c for c in ['Banco_Hoja','Banco_Fecha','Banco_Cheque_Ref','Banco_Movimiento','Banco_Detalle','Banco_Debito','Banco_Credito'] if c in full.columns]].drop_duplicates().copy()
    dates=pd.to_datetime(full['Maveric_Fecha'],errors='coerce'); mind=dates.min().date() if not dates.isna().all() else ''; maxd=dates.max().date() if not dates.isna().all() else ''; periodo=f'{mind}_a_{maxd}'.replace('-','')
    resumen=pd.DataFrame([['Banco',banco],['Moneda',moneda],['Versión',APP_VERSION],['Rango Maveric',f'{mind} a {maxd}'],['Movimientos Maveric',len(full)],['OK en BANCOS',int((full['Estado']=='OK en BANCOS').sum())],['REVISAR',int((full['Estado']=='REVISAR').sum())],['Faltan en Maveric',len(banco_falta)],['Maveric falta en bancos',len(mav_falta)],['Tolerancia OK','<= 0,10']],columns=['Concepto','Valor'])
    notas=pd.DataFrame([['Moneda','Concilia solo contra hoja bancaria de moneda elegida.'],['TC','Maveric Cliente/Proveedor con TC va a Tarjetas y no a Proveedores.'],['Tarjetas','Incluye Maveric y movimientos del banco con textos de tarjeta.'],['Proveedores','Incluye Maveric y movimientos del banco con textos de proveedor/pago.'],['Sevens/IATA','Sevens Travel contra IATA se toma como OK con importe coincidente.'],['Arqueo','Hoja Arqueo eliminada.']],columns=['Regla','Detalle'])
    bio=io.BytesIO()
    with pd.ExcelWriter(bio,engine='xlsxwriter',datetime_format='dd/mm/yyyy',date_format='dd/mm/yyyy') as w:
        sheets=[('Resumen',resumen),('Espejo_Maveric',full),('Ingresos',ing),('Egresos',egr),('Tarjetas',tarj),('Otros_datos',otros),('Revisar diferencias',rev),('Pago a Proveedores',prov),('Gasto Bancario',gasto),('Faltan en Maveric',banco_falta),('Maveric falta en bancos',mav_falta),('Banco_Usado',usado),('Banco_Rango_Maveric',bank_rango),('Notas_Reglas',notas)]
        for name,df in sheets: (df if name in ['Resumen','Notas_Reglas'] else total(df)).to_excel(w,sheet_name=name[:31],index=False)
        wb=w.book; head=wb.add_format({'bold':True,'bg_color':'#D9EAF7','border':1,'text_wrap':False}); money=wb.add_format({'num_format':'#,##0.00','text_wrap':False}); datef=wb.add_format({'num_format':'dd/mm/yyyy','text_wrap':False}); body=wb.add_format({'text_wrap':False,'valign':'vcenter'}); ok=wb.add_format({'bg_color':'#C6EFCE','font_color':'#006100'}); red=wb.add_format({'bg_color':'#FFC7CE','font_color':'#9C0006'}); grey=wb.add_format({'bg_color':'#E7E6E6'}); tot=wb.add_format({'bold':True,'top':2,'bg_color':'#F3F4F6'})
        for sn,ws in w.sheets.items():
            mr=ws.dim_rowmax; mc=ws.dim_colmax; ws.freeze_panes(1,0); ws.set_row(0,22,head)
            if mr is not None and mc is not None:
                ws.autofilter(0,0,mr,mc)
                for rr in range(1,mr+1): ws.set_row(rr,18,body)
                if sn not in ['Resumen','Notas_Reglas']: ws.set_row(mr,18,tot)
            ws.set_column(0,0,12,datef); ws.set_column(1,1,16,body); ws.set_column(2,5,24,body); ws.set_column(6,9,14,money); ws.set_column(10,12,22,body); ws.set_column(13,22,20,body)
            if sn=='Resumen': ws.set_column(0,0,40,body); ws.set_column(1,1,70,body)
            if sn=='Notas_Reglas': ws.set_column(0,0,24,body); ws.set_column(1,1,105,body)
            if mr and mc:
                ws.conditional_format(1,0,mr,mc,{'type':'formula','criteria':'=COUNTIF($A2:$Z2,"OK en BANCOS")>0','format':ok}); ws.conditional_format(1,0,mr,mc,{'type':'formula','criteria':'=COUNTIF($A2:$Z2,"REVISAR")>0','format':red}); ws.conditional_format(1,0,mr,mc,{'type':'formula','criteria':'=COUNTIF($A2:$Z2,"OTROS")>0','format':grey})
    bio.seek(0); return bio, {'filas':len(full),'ok':int((full['Estado']=='OK en BANCOS').sum()),'revisar':int((full['Estado']=='REVISAR').sum()),'periodo':periodo,'rango':f'{mind} a {maxd}','faltan_maveric':len(banco_falta)}

def run(banco_file,mav_file,banco_manual,moneda):
    bs=filter_currency(read_excel(banco_file,header=None),moneda); ms=read_excel(mav_file,header=None); banco=detect_bank(banco_file.name,banco_manual); mav=prepare_mav(ms); bank=prepare_bank(bs)
    if mav.empty: raise ValueError('No encontré movimientos válidos en Maveric.')
    d=pd.to_datetime(mav['Maveric_Fecha'],errors='coerce'); mind=d.min().date(); maxd=d.max().date(); bank_rango=bank[(bank['Banco_Fecha']>=mind)&(bank['Banco_Fecha']<=maxd)].copy() if not bank.empty else pd.DataFrame()
    full,used=classify(mav,bank,banco); excel,stats=build_excel(full,bank,bank_rango,used,banco,moneda); return excel,stats,banco

def save_copy(excel, filename, periodo):
    p=out_base()/str(periodo); p.mkdir(parents=True,exist_ok=True); f=p/filename; f.write_bytes(excel.getvalue()); return f

ok, mid, cfg=authorized()
with st.sidebar:
    if ICON_PATH.exists(): st.image(str(ICON_PATH),width=120)
    st.markdown('### Utilidades')
    if st.button('📁 Abrir carpeta de conciliaciones'): open_folder(out_base())
    st.markdown('---'); st.caption(f"Equipo: **{cfg.get('labels',{}).get(mid,'Equipo no identificado')}**"); st.caption(f"Versión {APP_VERSION}"); st.markdown('---'); st.caption('Conciliador Sevens')
if not ok: st.error('Este equipo no está autorizado.'); st.stop()
st.markdown('<div style="background:#eaf3f8;padding:22px;border-radius:16px;border:1px solid #c9dbe8;margin-bottom:18px;"><h1 style="margin:0;color:#111;">Conciliador Bancos - Maveric</h1><p style="margin:6px 0 0;color:#333;">Sevens Travel · salida desde Maveric, control contra bancos</p></div>', unsafe_allow_html=True)
st.markdown('## Cargar archivos')
c1,c2=st.columns(2)
with c1:
    st.markdown('### Subir Excel del banco'); banco_file=st.file_uploader('Subir Excel del banco',type=['xlsx','xls'],key='banco',label_visibility='collapsed')
with c2:
    st.markdown('### Subir XLS de Bancos Maveric'); mav_file=st.file_uploader('Subir XLS de Bancos Maveric',type=['xlsx','xls'],key='mav',label_visibility='collapsed')
c3,c4=st.columns([1,1])
with c3: banco_manual=st.text_input('Banco a buscar',value='',placeholder='ITAU / BROU / SANTANDER / HSBC')
with c4: moneda=st.selectbox('Moneda',['Dólares','Pesos','Euros'],index=0)
if banco_file and mav_file:
    if st.button('Generar conciliación',type='primary'):
        try:
            with st.spinner('Conciliando archivos...'):
                excel,stats,banco=run(banco_file,mav_file,banco_manual,moneda); now=datetime.now().strftime('%H%M'); moneda_slug=MONEDA_CFG[moneda]['slug']; fname=f"Conciliacion_Bancos_Maveric_{moneda_slug}_{banco}_{periodo_lindo(stats)}_v{APP_VERSION.replace('.','_')}_{now}.xlsx"; saved=save_copy(excel,fname,stats['periodo'])
            a,b,c,d=st.columns(4); a.metric('Movimientos',stats['filas']); b.metric('OK en BANCOS',stats['ok']); c.metric('Revisar',stats['revisar']); d.metric('Faltan en Maveric',stats['faltan_maveric']); st.success(f'Archivo guardado en: {saved}'); st.download_button('Descargar Excel conciliado',data=excel,file_name=fname,mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        except Exception as e: st.error(f'No pude generar la conciliación: {e}')
else: st.warning('Subí el Excel del banco y el Excel de Bancos Maveric.')
