
import io
import os
import re
import sys
import json
import uuid
import shutil
import hashlib
import platform
import subprocess
from datetime import datetime, date
from pathlib import Path

import pandas as pd
import numpy as np
import streamlit as st

APP_VERSION = "1.1"
APP_NAME = "Conciliador Bancos - Maveric Sevens"
APP_PORT = "8772"

st.set_page_config(page_title=APP_NAME, layout="wide", page_icon="💵")

# -----------------------------
# Config / paths
# -----------------------------

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
AUTH_FILE = ROOT_DIR / "authorized_machines.json"
ICON_PATH = APP_DIR / "assets" / "icon_sevens_bancos.png"

def local_documents_dir():
    home = Path.home()
    docs = home / "Documents"
    if not docs.exists():
        docs = home / "Documentos"
    docs.mkdir(exist_ok=True)
    return docs

def output_base_dir():
    base = local_documents_dir() / "archivos conciliados bancos maveric"
    base.mkdir(parents=True, exist_ok=True)
    return base

def open_folder(path: Path):
    try:
        path.mkdir(parents=True, exist_ok=True)
        system = platform.system().lower()
        if "darwin" in system:
            subprocess.Popen(["open", str(path)])
        elif "windows" in system:
            os.startfile(str(path))  # type: ignore
        else:
            subprocess.Popen(["xdg-open", str(path)])
        return True
    except Exception:
        return False

def install_if_missing(pkg_name, import_name=None):
    import_name = import_name or pkg_name
    try:
        __import__(import_name)
        return True
    except Exception:
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", pkg_name])
            return True
        except Exception:
            return False

def ensure_xls_support():
    try:
        import xlrd  # noqa
        return True
    except Exception:
        return install_if_missing("xlrd", "xlrd")

# -----------------------------
# Machine authorization
# -----------------------------

def run_cmd(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL, text=True).strip()
    except Exception:
        return ""

def machine_id():
    system = platform.system().lower()
    raw = ""
    if "darwin" in system:
        raw = run_cmd("ioreg -rd1 -c IOPlatformExpertDevice | awk -F'\\\"' '/IOPlatformUUID/{print $(NF-1)}'")
    elif "windows" in system:
        raw = run_cmd("powershell -NoProfile -Command \"(Get-CimInstance Win32_ComputerSystemProduct).UUID\"")
        if not raw:
            raw = run_cmd("wmic csproduct get uuid")
            raw = raw.replace("UUID", "").strip()
    else:
        raw = run_cmd("cat /etc/machine-id")
    if not raw:
        raw = str(uuid.getnode())
    return raw.strip().upper()

def default_auth_config():
    return {
        "admin_ids": [
            "00000000-0000-0000-0000-309C230BAEF1"
        ],
        "allowed_ids": [
            "00000000-0000-0000-0000-309C230BAEF1"
        ],
        "labels": {
            "00000000-0000-0000-0000-309C230BAEF1": "TUKI PC"
        },
        "allow_unregistered": True
    }

def load_auth_config():
    if not AUTH_FILE.exists():
        AUTH_FILE.write_text(json.dumps(default_auth_config(), indent=2), encoding="utf-8")
    try:
        cfg = json.loads(AUTH_FILE.read_text(encoding="utf-8"))
    except Exception:
        cfg = default_auth_config()
    # Normalizar listas sin duplicados
    for key in ["admin_ids", "allowed_ids"]:
        vals = []
        for v in cfg.get(key, []):
            uv = str(v).strip().upper()
            if uv and uv not in vals:
                vals.append(uv)
        cfg[key] = vals
    cfg.setdefault("allow_unregistered", True)
    cfg.setdefault("labels", {})
    return cfg

def is_authorized():
    cfg = load_auth_config()
    mid = machine_id()
    allowed = mid in cfg.get("allowed_ids", []) or cfg.get("allow_unregistered", True)
    admin = mid in cfg.get("admin_ids", [])
    return allowed, admin, mid, cfg

# -----------------------------
# Parsing utils
# -----------------------------

def to_number(x):
    if pd.isna(x):
        return 0.0
    if isinstance(x, (int, float, np.integer, np.floating)):
        return 0.0 if pd.isna(x) else float(x)
    s = str(x).strip()
    if not s or s == "-":
        return 0.0
    s = s.replace("$", "").replace("USD", "").replace("UYU", "").replace(" ", "")
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except Exception:
        return 0.0

def norm_text(x):
    if pd.isna(x):
        return ""
    return re.sub(r"\s+", " ", str(x).strip().upper().replace("ITAÚ", "ITAU"))

def parse_date_strict(x):
    if pd.isna(x):
        return pd.NaT
    if isinstance(x, (pd.Timestamp, datetime, date)):
        dt = pd.to_datetime(x, errors="coerce")
    elif isinstance(x, str):
        s = x.strip()
        if not s or not re.search(r"\d{1,4}[-/]\d{1,2}[-/]\d{1,4}", s):
            return pd.NaT
        dt = pd.to_datetime(s, errors="coerce", dayfirst=True)
    else:
        return pd.NaT
    if pd.isna(dt) or dt.year < 2020 or dt.year > 2035:
        return pd.NaT
    return dt

def is_blank_row(row):
    return all(pd.isna(v) or str(v).strip() == "" for v in row.values)

def row_contains_trash(row):
    txt = " ".join("" if pd.isna(v) else str(v) for v in row.values).upper().replace("Ó", "O")
    return (
        "TOTAL DE LA TRANSACCION" in txt
        or "TOTAL DE LA TRANSACCIÓN" in txt
        or "BALANCE DEL PERIODO" in txt
        or "BALANCE DEL PERÍODO" in txt
    )

def valid_pair(ing, egr):
    ing = to_number(ing)
    egr = to_number(egr)
    return (abs(ing) > 0 and abs(egr) == 0) or (abs(egr) > 0 and abs(ing) == 0)

def read_excel_uploaded(uploaded_file, header=None):
    name = uploaded_file.name.lower()
    data = uploaded_file.read()
    uploaded_file.seek(0)
    if name.endswith(".xls"):
        ensure_xls_support()
        return pd.read_excel(io.BytesIO(data), sheet_name=None, header=header, engine="xlrd")
    return pd.read_excel(io.BytesIO(data), sheet_name=None, header=header, engine="openpyxl")

def detect_bank_name(filename, manual_value):
    if manual_value and manual_value.strip():
        return manual_value.strip().upper().replace("ITAÚ", "ITAU")
    f = filename.upper().replace("ITAÚ", "ITAU")
    for b in ["ITAU", "BROU", "HSBC", "SANTANDER", "BBVA", "SCOTIABANK"]:
        if b in f:
            return b
    return "BANCO"

# -----------------------------
# Data prep
# -----------------------------

def prepare_maveric(workbook_sheets):
    first_sheet = list(workbook_sheets.keys())[0]
    raw = workbook_sheets[first_sheet]
    raw = raw[~raw.apply(is_blank_row, axis=1)].copy()
    dates = raw.iloc[:, 0].apply(parse_date_strict)
    mask = dates.notna() & (~raw.apply(row_contains_trash, axis=1))
    df = raw.loc[mask].copy().reset_index(drop=True)
    dates = dates.loc[mask].reset_index(drop=True)

    out = pd.DataFrame(index=df.index)
    out["Maveric_RowID"] = range(1, len(df) + 1)
    out["Maveric_Fecha"] = pd.to_datetime(dates).dt.date
    out["Maveric_Movimiento"] = df.iloc[:, 1] if df.shape[1] > 1 else ""
    out["Maveric_Origen"] = df.iloc[:, 2] if df.shape[1] > 2 else ""
    out["Maveric_Destino"] = df.iloc[:, 3] if df.shape[1] > 3 else ""
    out["Maveric_Detalle"] = df.iloc[:, 4] if df.shape[1] > 4 else ""
    out["Maveric_Concepto"] = df.iloc[:, 5] if df.shape[1] > 5 else ""
    out["Maveric_Ingreso"] = df.iloc[:, 6].apply(to_number) if df.shape[1] > 6 else 0.0
    out["Maveric_Egreso"] = df.iloc[:, 7].apply(to_number) if df.shape[1] > 7 else 0.0
    out["Maveric_Texto_Busqueda"] = (
        out["Maveric_Movimiento"].astype(str) + " " +
        out["Maveric_Detalle"].astype(str) + " " +
        out["Maveric_Concepto"].astype(str)
    ).map(norm_text)
    out["Par_Ingreso_Egreso_Valido"] = out.apply(
        lambda r: valid_pair(r["Maveric_Ingreso"], r["Maveric_Egreso"]),
        axis=1
    )
    return out.reset_index(drop=True)

def prepare_bank_all(workbook_sheets):
    all_rows = []
    for sheet_name, raw in workbook_sheets.items():
        raw = raw[~raw.apply(is_blank_row, axis=1)].copy()
        if raw.empty or raw.shape[1] < 7:
            continue
        dates = raw.iloc[:, 0].apply(parse_date_strict)
        mask = dates.notna() & (~raw.apply(row_contains_trash, axis=1))
        df = raw.loc[mask].copy().reset_index(drop=True)
        dates = dates.loc[mask].reset_index(drop=True)
        if df.empty:
            continue

        out = pd.DataFrame(index=df.index)
        out["Banco_Hoja"] = sheet_name
        out["Banco_Fecha"] = pd.to_datetime(dates).dt.date
        out["Banco_Cheque_Ref"] = df.iloc[:, 1] if df.shape[1] > 1 else ""
        out["Banco_Movimiento"] = df.iloc[:, 2] if df.shape[1] > 2 else ""
        out["Banco_Detalle"] = df.iloc[:, 3] if df.shape[1] > 3 else ""
        out["Banco_Debito"] = df.iloc[:, 5].apply(to_number) if df.shape[1] > 5 else 0.0
        out["Banco_Credito"] = df.iloc[:, 6].apply(to_number) if df.shape[1] > 6 else 0.0
        out["Banco_Texto_Busqueda"] = (
            out["Banco_Cheque_Ref"].astype(str) + " " +
            out["Banco_Movimiento"].astype(str) + " " +
            out["Banco_Detalle"].astype(str)
        ).map(norm_text)
        all_rows.append(out)
    if not all_rows:
        return pd.DataFrame()
    return pd.concat(all_rows, ignore_index=True)

# -----------------------------
# Matching / categorization
# -----------------------------

def text_match(mav_text, bank_text):
    mt = norm_text(mav_text)
    bt = norm_text(bank_text)
    if not mt or not bt:
        return False
    stop = {"EFECTIVO", "BANCO", "ITAU", "PAGO", "TRANSFERENCIA", "GASTOS", "GASTO", "CH", "SA", "SAS", "SRL", "LTDA", "CLIENTES"}
    words = [w for w in re.split(r"[^A-Z0-9ÁÉÍÓÚÑ]+", mt) if len(w) >= 4 and w not in stop]
    return any(w in bt for w in words) or mt in bt or bt in mt

def same_date(a, b):
    da = pd.to_datetime(a, errors="coerce")
    db = pd.to_datetime(b, errors="coerce")
    return (not pd.isna(da)) and (not pd.isna(db)) and da.date() == db.date()

def movement_tokens(value):
    s = norm_text(value)
    return [w for w in re.split(r"[^A-Z0-9]+", s) if len(w) >= 4 and any(ch.isdigit() for ch in w)]

def contains_arqueo(row):
    txt = " ".join(norm_text(v) for v in row.values)
    return "ARQUEO" in txt

def classify_and_match(mav, bank, banco_name):
    banco_key = norm_text(banco_name)
    rows = []
    used_bank = set()

    for _, r in mav.iterrows():
        ingreso = to_number(r["Maveric_Ingreso"])
        egreso = to_number(r["Maveric_Egreso"])
        origen = norm_text(r["Maveric_Origen"])
        destino = norm_text(r["Maveric_Destino"])
        detalle = norm_text(r["Maveric_Detalle"])
        concepto = norm_text(r["Maveric_Concepto"])

        tipo = "Otros"
        amount = None
        bank_col = None
        motivo_base = ""

        if not r["Par_Ingreso_Egreso_Valido"]:
            motivo_base = "Ingreso/Egreso inválido: uno debe ser cero"
        elif banco_key in destino and ingreso > 0 and egreso == 0:
            tipo, amount, bank_col = "Ingreso", ingreso, "Banco_Credito"
        elif banco_key in origen and egreso > 0 and ingreso == 0:
            tipo, amount, bank_col = "Egreso", egreso, "Banco_Debito"
        elif banco_key in origen or banco_key in destino:
            motivo_base = "Banco aparece pero el importe está en columna contraria"
        else:
            motivo_base = "Origen/Destino no contiene banco"

        match = None
        estado = "OTROS" if tipo == "Otros" else "REVISAR"
        motivo = motivo_base
        fecha_en_bancos = ""

        if tipo in ["Ingreso", "Egreso"] and not bank.empty:
            amount_candidates = bank[bank[bank_col].round(2) == round(amount, 2)].copy()
            movs = movement_tokens(r["Maveric_Movimiento"])
            doc_candidates = []

            if movs and not amount_candidates.empty:
                for bidx, br in amount_candidates.iterrows():
                    bank_text = norm_text(br["Banco_Texto_Busqueda"])
                    if any(tok in bank_text for tok in movs):
                        doc_candidates.append((bidx, br))

            if doc_candidates:
                scored = []
                for bidx, br in doc_candidates:
                    score = 100
                    if bidx not in used_bank:
                        score += 10
                    if text_match(r["Maveric_Texto_Busqueda"], br["Banco_Texto_Busqueda"]):
                        score += 8
                    if same_date(r["Maveric_Fecha"], br["Banco_Fecha"]):
                        score += 5
                    scored.append((score, bidx, br))
                scored.sort(key=lambda x: x[0], reverse=True)
                _, best_idx, match = scored[0]
                used_bank.add(best_idx)
                estado = "OK en BANCOS"
                fecha_en_bancos = match.get("Banco_Fecha", "")
                motivo = "Importe + documento encontrado en bancos"
                if not same_date(r["Maveric_Fecha"], fecha_en_bancos):
                    motivo += " en otra fecha"
            else:
                same_day = amount_candidates[amount_candidates["Banco_Fecha"].apply(lambda x: same_date(r["Maveric_Fecha"], x))].copy()
                if same_day.empty:
                    estado = "REVISAR"
                    motivo = "No encontré importe/documento en banco"
                else:
                    scored = []
                    for bidx, br in same_day.iterrows():
                        score = 0
                        if bidx not in used_bank:
                            score += 10
                        if text_match(r["Maveric_Texto_Busqueda"], br["Banco_Texto_Busqueda"]):
                            score += 8
                        scored.append((score, bidx, br))
                    scored.sort(key=lambda x: x[0], reverse=True)
                    best_score, best_idx, match = scored[0]
                    used_bank.add(best_idx)
                    fecha_en_bancos = match.get("Banco_Fecha", "")
                    if best_score >= 18:
                        estado = "OK en BANCOS"
                        motivo = "Importe + misma fecha + texto"
                    else:
                        estado = "REVISAR"
                        motivo = "Importe + misma fecha, revisar texto"

        out = r.to_dict()
        out["Tipo"] = tipo
        out["Es_Tarjeta"] = "SI" if ("TRJ" in concepto or "TARJETAS" in origen) else "NO"
        out["Es_Pago_Proveedor"] = "SI" if "PROVEEDORES" in destino else "NO"
        out["Es_Gasto_Bancario"] = "SI" if ("GASTO BANCARIO" in (destino + " " + detalle) or "GASTOS BANCARIOS" in (destino + " " + detalle)) else "NO"
        out["Es_Arqueo"] = "SI" if contains_arqueo(r) else "NO"
        out["Estado"] = estado
        out["Fecha en Bancos"] = fecha_en_bancos
        out["Motivo"] = motivo

        if match is not None:
            out.update({
                "Banco_Hoja": match.get("Banco_Hoja", ""),
                "Banco_Fecha": match.get("Banco_Fecha", ""),
                "Banco_Cheque_Ref": match.get("Banco_Cheque_Ref", ""),
                "Banco_Movimiento": match.get("Banco_Movimiento", ""),
                "Banco_Detalle": match.get("Banco_Detalle", ""),
                "Banco_Debito": match.get("Banco_Debito", 0.0),
                "Banco_Credito": match.get("Banco_Credito", 0.0),
            })
        else:
            out.update({
                "Banco_Hoja": "", "Banco_Fecha": "", "Banco_Cheque_Ref": "",
                "Banco_Movimiento": "", "Banco_Detalle": "",
                "Banco_Debito": 0.0, "Banco_Credito": 0.0,
            })
        rows.append(out)
    return pd.DataFrame(rows)

# -----------------------------
# Excel
# -----------------------------

def add_total_row(df):
    df = df.copy()
    if df.empty:
        return df
    total = {c: "" for c in df.columns}
    total[df.columns[0]] = "TOTAL"
    for c in ["Maveric_Ingreso", "Maveric_Egreso", "Banco_Debito", "Banco_Credito"]:
        if c in df.columns:
            total[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).sum()
    return pd.concat([df, pd.DataFrame([total])], ignore_index=True)

def build_excel(full, bank_all, bank_rango, banco_nombre, mav_filename):
    cols = [
        "Maveric_RowID", "Maveric_Fecha", "Maveric_Movimiento", "Maveric_Origen", "Maveric_Destino",
        "Maveric_Detalle", "Maveric_Concepto", "Maveric_Ingreso", "Maveric_Egreso",
        "Tipo", "Es_Tarjeta", "Es_Pago_Proveedor", "Es_Gasto_Bancario", "Es_Arqueo",
        "Estado", "Fecha en Bancos", "Motivo",
        "Banco_Hoja", "Banco_Fecha", "Banco_Cheque_Ref", "Banco_Movimiento", "Banco_Detalle",
        "Banco_Debito", "Banco_Credito", "Par_Ingreso_Egreso_Valido"
    ]
    full = full[[c for c in cols if c in full.columns]].copy()

    ingresos = full[(full["Tipo"]=="Ingreso") & (full["Maveric_Ingreso"].abs()>0) & (full["Maveric_Egreso"].abs()==0)].copy()
    egresos = full[(full["Tipo"]=="Egreso") & (full["Maveric_Egreso"].abs()>0) & (full["Maveric_Ingreso"].abs()==0)].copy()
    tarjetas = full[full["Es_Tarjeta"]=="SI"].copy()
    revisar = full[full["Estado"]=="REVISAR"].copy()
    pago_proveedores = full[full["Es_Pago_Proveedor"]=="SI"].copy()
    gasto_bancario = full[full["Es_Gasto_Bancario"]=="SI"].copy()
    arqueo = full[full["Es_Arqueo"]=="SI"].copy()
    otros = full[
        (full["Tipo"]=="Otros")
        & (full["Es_Tarjeta"]!="SI")
        & (full["Es_Pago_Proveedor"]!="SI")
        & (full["Es_Gasto_Bancario"]!="SI")
        & (full["Es_Arqueo"]!="SI")
    ].copy()

    banco_usado = full[full["Banco_Fecha"].astype(str).str.strip() != ""][
        ["Banco_Hoja", "Banco_Fecha", "Banco_Cheque_Ref", "Banco_Movimiento", "Banco_Detalle", "Banco_Debito", "Banco_Credito"]
    ].drop_duplicates().copy()

    mav_dates = pd.to_datetime(full["Maveric_Fecha"], errors="coerce")
    min_date = mav_dates.min().date() if not mav_dates.isna().all() else ""
    max_date = mav_dates.max().date() if not mav_dates.isna().all() else ""
    periodo = f"{min_date}_a_{max_date}".replace("-", "")

    resumen = pd.DataFrame([
        ["Banco detectado", banco_nombre],
        ["Versión lógica", APP_VERSION],
        ["Fecha creación", datetime.now().strftime("%d/%m/%Y %H:%M")],
        ["Archivo Maveric usado", mav_filename],
        ["Rango Maveric leído", f"{min_date} a {max_date}"],
        ["Filas Maveric limpias", len(full)],
        ["OK en BANCOS", int((full["Estado"]=="OK en BANCOS").sum())],
        ["REVISAR", int((full["Estado"]=="REVISAR").sum())],
        ["OTROS", int((full["Estado"]=="OTROS").sum())],
        ["Ingresos", len(ingresos)],
        ["Egresos", len(egresos)],
        ["Tarjetas", len(tarjetas)],
        ["Pago a Proveedores", len(pago_proveedores)],
        ["Gasto Bancario", len(gasto_bancario)],
        ["Arqueo", len(arqueo)],
        ["Otros datos", len(otros)],
        ["Total ingresos Maveric", ingresos["Maveric_Ingreso"].sum()],
        ["Total créditos Banco vinculados a ingresos", ingresos["Banco_Credito"].sum()],
        ["Diferencia ingresos", ingresos["Maveric_Ingreso"].sum() - ingresos["Banco_Credito"].sum()],
        ["Total egresos Maveric", egresos["Maveric_Egreso"].sum()],
        ["Total débitos Banco vinculados a egresos", egresos["Banco_Debito"].sum()],
        ["Diferencia egresos", egresos["Maveric_Egreso"].sum() - egresos["Banco_Debito"].sum()],
    ], columns=["Concepto", "Valor"])

    notas = pd.DataFrame([
        ["Base", "La salida se arma únicamente con filas de Maveric. El banco no agrega movimientos propios."],
        ["Búsqueda en bancos", "Busca documento/movimiento de Maveric en todo el archivo de bancos, aunque sea otra fecha."],
        ["Estado", "OK en BANCOS en verde. REVISAR en rojo."],
        ["Formato", "Sin bandas celestes/blancas, sin ajuste de texto masivo, columnas anchas y filas normales."],
        ["Guardado", "Además del botón de descarga, guarda copia automática en Documentos/archivos conciliados bancos maveric/<periodo>."],
    ], columns=["Regla", "Detalle"])

    output = io.BytesIO()
    with pd.ExcelWriter(output, engine="xlsxwriter", datetime_format="dd/mm/yyyy", date_format="dd/mm/yyyy") as writer:
        sheets = [
            ("Resumen", resumen),
            ("Espejo_Maveric", full),
            ("Ingresos", ingresos),
            ("Egresos", egresos),
            ("Tarjetas", tarjetas),
            ("Otros_datos", otros),
            ("Revisar diferencias", revisar),
            ("Pago a Proveedores", pago_proveedores),
            ("Gasto Bancario", gasto_bancario),
            ("Arqueo", arqueo),
            ("Banco_Usado", banco_usado),
            ("Banco_Rango_Maveric", bank_rango),
            ("Notas_Reglas", notas),
        ]
        for name, df in sheets:
            if name not in ["Resumen", "Notas_Reglas"]:
                df = add_total_row(df)
            df.to_excel(writer, sheet_name=name, index=False)

        wb = writer.book
        header_fmt = wb.add_format({"bold": True, "bg_color": "#D9EAF7", "border": 1, "text_wrap": False, "valign": "vcenter"})
        money_fmt = wb.add_format({"num_format": "#,##0.00", "text_wrap": False, "valign": "vcenter"})
        date_fmt = wb.add_format({"num_format": "dd/mm/yyyy", "text_wrap": False, "valign": "vcenter"})
        total_fmt = wb.add_format({"bold": True, "top": 2, "bg_color": "#F3F4F6", "text_wrap": False})
        ok_fmt = wb.add_format({"bg_color": "#C6EFCE", "font_color": "#006100", "text_wrap": False})
        rev_fmt = wb.add_format({"bg_color": "#FFC7CE", "font_color": "#9C0006", "text_wrap": False})
        otros_fmt = wb.add_format({"bg_color": "#E7E6E6", "text_wrap": False})
        body_fmt = wb.add_format({"text_wrap": False, "valign": "vcenter"})

        for sheet_name, ws in writer.sheets.items():
            max_row = ws.dim_rowmax
            max_col = ws.dim_colmax
            ws.freeze_panes(1, 0)
            ws.set_row(0, 22, header_fmt)
            if max_row is not None and max_col is not None:
                ws.autofilter(0, 0, max_row, max_col)
                for rr in range(1, max_row + 1):
                    ws.set_row(rr, 18, body_fmt)
                if sheet_name not in ["Resumen", "Notas_Reglas"]:
                    ws.set_row(max_row, 18, total_fmt)

            ws.set_column(0, 0, 12, body_fmt)
            ws.set_column(1, 1, 12, date_fmt)
            ws.set_column(2, 2, 16, body_fmt)
            ws.set_column(3, 4, 22, body_fmt)
            ws.set_column(5, 6, 30, body_fmt)
            ws.set_column(7, 8, 14, money_fmt)
            ws.set_column(9, 13, 16, body_fmt)
            ws.set_column(14, 14, 16, body_fmt)
            ws.set_column(15, 15, 15, date_fmt)
            ws.set_column(16, 16, 42, body_fmt)
            ws.set_column(17, 21, 22, body_fmt)
            ws.set_column(22, 23, 14, money_fmt)
            ws.set_column(24, 24, 16, body_fmt)

            if sheet_name == "Resumen":
                ws.set_column(0, 0, 42, body_fmt)
                ws.set_column(1, 1, 85, body_fmt)
            if sheet_name == "Notas_Reglas":
                ws.set_column(0, 0, 24, body_fmt)
                ws.set_column(1, 1, 105, body_fmt)

            # Conditional by Estado if present
            # Use formula with MATCH to avoid fixed column issues
            if max_row and max_col:
                ws.conditional_format(1, 0, max_row, max_col, {"type": "formula", "criteria": '=COUNTIF($A2:$Z2,"OK en BANCOS")>0', "format": ok_fmt})
                ws.conditional_format(1, 0, max_row, max_col, {"type": "formula", "criteria": '=COUNTIF($A2:$Z2,"REVISAR")>0', "format": rev_fmt})
                ws.conditional_format(1, 0, max_row, max_col, {"type": "formula", "criteria": '=COUNTIF($A2:$Z2,"OTROS")>0', "format": otros_fmt})

    output.seek(0)
    stats = {
        "filas": len(full),
        "ok": int((full["Estado"]=="OK en BANCOS").sum()),
        "revisar": int((full["Estado"]=="REVISAR").sum()),
        "otros": int((full["Estado"]=="OTROS").sum()),
        "periodo": periodo,
        "rango": f"{min_date} a {max_date}",
    }
    return output, stats

def run_conciliation(banco_file, maveric_file, banco_nombre):
    banco_sheets = read_excel_uploaded(banco_file, header=None)
    mav_sheets = read_excel_uploaded(maveric_file, header=None)
    banco_nombre = detect_bank_name(banco_file.name, banco_nombre)
    mav = prepare_maveric(mav_sheets)
    bank_all = prepare_bank_all(banco_sheets)
    if mav.empty:
        raise ValueError("No encontré movimientos válidos en Maveric.")

    mav_dates = pd.to_datetime(mav["Maveric_Fecha"], errors="coerce")
    min_date = mav_dates.min().date()
    max_date = mav_dates.max().date()
    bank_rango = bank_all[(bank_all["Banco_Fecha"] >= min_date) & (bank_all["Banco_Fecha"] <= max_date)].copy() if not bank_all.empty else pd.DataFrame()

    full = classify_and_match(mav, bank_all, banco_nombre)
    excel, stats = build_excel(full, bank_all, bank_rango, banco_nombre, maveric_file.name)
    return excel, stats, banco_nombre

def save_excel_copy(excel_bytes, filename, periodo):
    dest_dir = output_base_dir() / str(periodo)
    dest_dir.mkdir(parents=True, exist_ok=True)
    path = dest_dir / filename
    path.write_bytes(excel_bytes.getvalue())
    return path

# -----------------------------
# UI estilo IATA
# -----------------------------

allowed, admin, mid, auth_cfg = is_authorized()

with st.sidebar:
    if ICON_PATH.exists():
        st.image(str(ICON_PATH), width=120)
    st.markdown("### Utilidades")
    if st.button("📁 Abrir carpeta de conciliaciones"):
        if open_folder(output_base_dir()):
            st.success("Carpeta abierta.")
        else:
            st.warning(str(output_base_dir()))
    st.markdown("---")
    st.caption(f"Equipo: `{mid}`")
    st.caption(f"Versión {APP_VERSION}")
    if admin:
        with st.expander("Admin / Equipos autorizados"):
            st.json(auth_cfg)
            st.caption("Editar authorized_machines.json para agregar/quitar equipos.")
    st.markdown("---")
    st.caption("Conciliador Sevens")

if not allowed:
    st.error("Este equipo no está autorizado para usar el conciliador.")
    st.code(mid)
    st.stop()

st.markdown(
    """
    <div style="background:#eaf3f8;padding:22px;border-radius:16px;border:1px solid #c9dbe8;margin-bottom:18px;">
      <h1 style="margin:0;color:#111;">Conciliador Bancos - Maveric</h1>
      <p style="margin:6px 0 0;color:#333;">Sevens Travel · salida desde Maveric, control contra bancos</p>
    </div>
    """,
    unsafe_allow_html=True,
)

st.markdown("### Cargar archivos")

col1, col2 = st.columns(2)
with col1:
    banco_file = st.file_uploader("Subir Excel del banco", type=["xlsx", "xls"], key="banco_front")
with col2:
    maveric_file = st.file_uploader("Subir XLS de Bancos Maveric", type=["xlsx", "xls"], key="mav_front")

col3, col4 = st.columns([1, 2])
with col3:
    banco_manual = st.text_input("Banco a buscar", value="", placeholder="ITAU / BROU / HSBC")
with col4:
    st.info("Si el banco aparece en el nombre del archivo, lo detecto solo. Si no, escribilo acá.")

if banco_file and maveric_file:
    if st.button("Generar conciliación", type="primary"):
        try:
            with st.spinner("Conciliando archivos..."):
                excel, stats, banco_nombre = run_conciliation(banco_file, maveric_file, banco_manual)
                now = datetime.now().strftime("%H%M")  # hora local de la máquina que ejecuta
                filename = f"Conciliacion_Bancos_Maveric_{banco_nombre}_{stats['periodo']}_v{APP_VERSION.replace('.', '_')}_{now}.xlsx"
                saved_path = save_excel_copy(excel, filename, stats["periodo"])

            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Movimientos", stats["filas"])
            c2.metric("OK en BANCOS", stats["ok"])
            c3.metric("Revisar", stats["revisar"])
            c4.metric("Otros", stats["otros"])

            st.success(f"Archivo guardado en: {saved_path}")
            st.download_button(
                "Descargar Excel conciliado",
                data=excel,
                file_name=filename,
                mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        except Exception as e:
            st.error(f"No pude generar la conciliación: {e}")
else:
    st.warning("Subí el Excel del banco y el Excel de Bancos Maveric.")
